create trigger sign_in
  before INSERT
  on user
  for each row
  BEGIN
SET new.user_register_time = NOW();
SET new.user_headportrait = "default_head.jpg";
end;

